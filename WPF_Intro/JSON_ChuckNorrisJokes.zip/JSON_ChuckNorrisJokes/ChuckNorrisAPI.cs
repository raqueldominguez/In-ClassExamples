﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JSON_ChuckNorrisJokes
{
    public class ChuckNorrisAPI
    {
        public string Icon_URL {get; set;}
        public string Id { get; set; }
        public string Url { get; set; }
        public string Value { get; set; }
    }
}
